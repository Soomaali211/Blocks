# Blocks & Plots — Android app (offline)

App Android ah oo madax-bannaan: **WebView** ayaa ku shubaya nidaamka Blocks & Plots (HTML) oo ku jira APK-ga gudihiisa.
Wax internet ah ma u baahna (APK-gu ma leh INTERNET permission), xogtuna waxay ku hadhaysaa telefoonkaaga.

## Waxa ku jira
- Dhammaan shaqooyinkii hore: blocks/plots/half-plots, xuduud, aag gaar ah, xulasho & mulkiilayaal, exports (Shapefile, GeoJSON, CSV, PDF).
- **Auto-Save**: shaqadu si toos ah ayay u kaydsantaa; marka app-ka dib loo furo, waa soo laabanaysaa.
- **Drafts**: kaydi nuqullo magac leh, fur, tirtir, iyo "Dib u celi shaqadii hore".
- **Backup / Restore**: file JSON ah (dhammaan drafts + shaqada hadda); ku soo celi telefoon cusub ama kadib rakibid cusub.
- **Offline buuxa**: proj4 (UTM) iyo ZIP waa gudaha HTML-ka; font/CDN lama isticmaalo.
- Faylasha waxaa lagu keydiyaa/furaa **system file picker** (permission looma baahna).

## Habka ugu fudud ee APK looga dhisayo telefoonka (GitHub — bilaash, ~10 daqiiqo)
Waxaad u baahan tahay oo keliya browser iyo akoon GitHub ah.

1. Fur **github.com** → geli / is-diiwaangeli → **New repository** (magac: `blocks-plots`, dooro *Public* ama *Private*) → **Create repository**.
2. Repository-ga cusub: **Add file → Upload files** → dooro **`BlocksPlots_Android_Project.zip`** (hal zip kaliya ha ku jiro repo-ga) → **Commit changes**.
3. **Add file → Create new file** → magaca geli: `.github/workflows/build-apk.yml` → ku dheji nuqulka file-ka **`build-apk.yml`** (waa kan ku jira zip-ka iyo file gooni ah) → **Commit changes**.
4. Tab-ka **Actions** → **Build APK** → **Run workflow**. Sug ~4–7 daqiiqo ilaa ay noqoto ✅ cagaar ah.
5. Tag **Releases** (bidix/hoose repo-ga) → fur release-ka ugu dambeeyay → taabo **`BlocksPlots.apk`** si aad u soo degsato.
   *(Beddel: Actions → run-ka → Artifacts → `BlocksPlots-APK` (zip, ku fur Files app).)*
6. Fur APK-ga → haddii loo baahdo ogolow **"Install unknown apps"** browser-ka/Files app-ka → **Install**.

Ogow: APK-gan waa **debug-signed** (waa la rakibi karaa; Play Store uma habboona). Haddii aad rabto APK release ah oo la saxiixay, weydiiso nidaamka.

## Habka PC (Android Studio)
1. Fur Android Studio → **Open** → dooro galka `BlocksPlots` (kan zip-ka laga soo furay).
2. Sug Gradle sync (internet ayaa loo baahan yahay markii ugu horreysay).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**. APK: `app/build/outputs/apk/debug/app-debug.apk`.
4. U gudbi telefoonka (USB/WhatsApp/Drive) oo rakib.

(Command line: `gradle assembleDebug` — JDK 17 + Android SDK 34 + Gradle 8.5.)

## Isticmaalka kaydinta
- **Auto-Save** wuu shidan yahay si caadi ah (qaybta 5). Wuxuu kaydiyaa ~1 ilbiriqsi ka dib isbeddel kasta iyo marka app-ka laga baxo.
- Xogta waxay ku jirtaa kaydka gudaha ee app-ka. **Haddii aad "Clear data" samayso ama aad app-ka tirtirto, xogta way baaba'aysaa** — hore u samee **Backup** oo kaydi file-ka (Drive/WhatsApp/Files).
- **Restore**: qaybta 5 → *Restore* → dooro file-ka Backup. "Ku dar" waxay ku darsataa drafts-ka; "Beddel dhammaan" waxay bedelaysaa drafts-ka iyo shaqada hadda (waxaa jira "Dib u celi shaqadii hore").

## Dhibaatooyin
- **Soo dejintu ma shaqayso**: ogolow file picker-ka; dooro meel (Downloads/Drive) kadibna "Save".
- **Map-ka waa yar yahay**: gacmo-laba ku weyneey (pinch) ama badhamada +/−.
- **Faylka GeoJSON lama arko picker-ka**: dooro "Files" ama "Browse"; app-ku wuxuu u ogolyahay file kasta.
